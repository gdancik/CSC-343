######################################################################
# String operations
# see http://www.tutorialspoint.com/python/python_strings.htm for more
######################################################################

string = "Hello, how are you?"
print("string = ", string)
print("length = ", len(string))
print("First letter:", string[0]) # index starts at 0
print()

# ranges of strings (and lists) can be specified through an operation
# known as 'splicing', where string[a:b] returns the characters starting 
# at index 'a' and up to but NOT including index 'b'. 
# Note that 'a' and 'b' are optional, as seen below
print("First three letters are: ", string[0:3])
print("First three letters are: ", string[:3]) # start at beg of string by default
print("Skip the first 3 letters: ", string[3:]) # go to end of string by default
print()

# you can use the form [a:b:i] to get letters from index 'a' through 
# (but not including) 'b', selecting every ith letter, with i = 1 by default)
print("Every other letter is: ", string[0::2])
print("Every other letter is: ", string[::2]) # goes from beginning - end by default
print()

# i can be negative (use i = -1 to reverse the string)
print("Part of string in reverse is: ", string[len(string)::-1])
# but since 'a' and 'b' are optional, we can use:
print("String in reverse is: ", string[::-1])
print()

# negative values for 'a' and/or 'b' specify offset from the
# last index
print("The last 4 characters in the string are: ", string[-4:])
print()


# all uppercase
print ("Uppercase string: ", string.upper())
# all lowercase
print ("Lowercase string: ", string.lower())

# note: the 'upper' and 'lower' methods do not change the original 
# string (they create a copy of the string in all upper or lower case)
# if you want to change the string, you need to assign it:
# string = string.upper()

# count number of 'e's in the string (case sensitive count)
numE = string.count('e')
print("Number of 'e's =", numE)

# find a substring
print ("Index of ' ': ", string.find(' ')) # index of first occurence if found
print ("Index of ABC : ", string.find("ABC")) # return -1 if not found

# does string contain a substring?
print("The string is: ", string)
print ("string contains \"how\":", "how" in string)
print ("string contains \"where\":", "where" in string)

# replace will create a copy of a string, replacing the first argument
# with the second
s = "This is a sentence"
s = s.replace("This", "That")
print(s)


######################################################################
# Exercise:
# 1) Using splicing and the find method, find and output the first word 
#    of userInput (all characters before the first blank space)
######################################################################

# prompt user to enter a string, stored in userInput
userInput = input("Enter a string with at least 2 words: ")
print("You entered:", userInput)

